package com.humber.week12springdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week12SpringDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
