package com.humber.week12springdemo.model;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDate;
import java.time.Period;

@Data
@Builder
public class Student {
    private int id;
    private String firstName;
    private String lastName;
    private String program;
    private LocalDate dateOfBirth;

    // Assume other fields, constructors, getters, and setters are here

    // Getter method to calculate age from dateOfBirth
    public int getAge() {
        if (this.dateOfBirth == null) {
            // Handle the case when the date of birth is not set
            return -1; // or some other indicative value
        }
        return Period.between(this.dateOfBirth, LocalDate.now()).getYears();
    }
}
