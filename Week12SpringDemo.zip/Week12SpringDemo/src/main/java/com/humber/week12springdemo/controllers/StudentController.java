package com.humber.week12springdemo.controllers;

import com.humber.week12springdemo.model.Student;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

@Controller
public class StudentController {

    @GetMapping("/")
    public String home(HttpSession session){
        session.setAttribute("appName","Whiteboard");
        return "index";
    }

    @GetMapping("/students")
    public String studentPage(Model model){
        model.addAttribute("students",getStudents());
        return "students";
    }

    private List<Student> getStudents() {
        return Arrays.asList(
                Student.builder()
                        .id(1)
                        .firstName("Fred")
                        .lastName("Smith")
                        .program("ICT")
                        .dateOfBirth(LocalDate.of(2004, Month.JANUARY, 1))
                        .build(),
                Student.builder()
                        .id(2)
                        .firstName("Shinzo")
                        .lastName("Smith")
                        .program("EAP")
                        .dateOfBirth(LocalDate.of(2005, Month.FEBRUARY, 2))
                        .build(),
                Student.builder()
                        .id(3)
                        .firstName("Daisy")
                        .lastName("Smith")
                        .program("ICT")
                        .dateOfBirth(LocalDate.of(2006, Month.MARCH, 3))
                        .build(),
                Student.builder()
                        .id(4)
                        .firstName("Corey")
                        .lastName("Smith")
                        .program("ICT")
                        .dateOfBirth(LocalDate.of(2007, Month.APRIL, 4))
                        .build(),
                Student.builder()
                        .id(5)
                        .firstName("Barney")
                        .lastName("Smith")
                        .program("ICT")
                        .dateOfBirth(LocalDate.of(2008, Month.MAY, 5))
                        .build(),
                Student.builder()
                        .id(6)
                        .firstName("Wilma")
                        .lastName("Smith")
                        .program("ICT")
                        .dateOfBirth(LocalDate.of(2009, Month.JUNE, 6))
                        .build()
        );
    }
}
