package com.humber.week12springdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week12SpringDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(Week12SpringDemoApplication.class, args);
    }

}
